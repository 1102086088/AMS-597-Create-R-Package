#' Linear regression
#'
#' linr is a function to run linear regression for a data set with continuous
#' dependent variable.
#'
#' y  independent variable, a continuous vector
#'
#' X  dependent variables, a n by p matrix
#'
#' @export


linr <- function(y, X) {
  if (length(unique(y)) == 2) {
    warning("The response variable is binary, should apply logstic regression. Use the function \"logr()\".")
  }

  df <- data.frame(y, X)

  n <- dim(X)[1]    # number of observations
  p <- dim(X)[2]    # number of parameters
  if (n < p) {
    warning("The number of predictors is greater than the number of observations. Insignificant variables are elimated.")
    df <- df[, fwd.sel(y, X, vmax = n-1, model = "lm", shrinkage = T)]
  }

  f <- lm(y ~ (.), data = df)
  coefficients <- summary(f)$coefficients
  fitted.values <- f$fitted.values

  r <- list(lm = f, coefficients = coefficients, fitted.values = fitted.values)

  return(r)
}
