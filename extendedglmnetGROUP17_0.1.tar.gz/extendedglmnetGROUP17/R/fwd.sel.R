#' Forward Selection
#'
#' fwd.sel is a function to do variable selection, it will return the
#' index of variables that need to be kept in the prediction model. This function
#' is not supposed to be exposed to users to use.
#'
#' y  independent variable, a vector
#'
#' X  dependent variables, a n by p matrix
#'
#' vmax  the number of independent variables supposs to be kept
#'
#' model the type of regression model ()
#'
#' shrinkage  shrinkage=True means it needs to reduce the number of independent variables


fwd.sel <- function(y, X, vmax = 1, model = "lm", shrinkage = F) {
  df <- data.frame(y, X)
  i <- c(2:dim(df)[2])

  if (vmax > 30) {
    warning("vmax > 30, the function takes a long time to execute.")
    if (shrinkage == T) {
      vmax <- 12
      warning("shrinkage = T, \"vax\" is set equal to be 12 automatically.")
    }
  }

  v <- 0
  j <- c(1)
  if (model == "lm") {
    while (v < vmax) {
      AIC <- rep(Inf, dim(df)[2])
      for (k in i) {
        d <- df[, c(j, k)]
        f <- lm(y ~ (.), data = d)
        AIC[k] <- AIC(f)
      }
      s <- which(rank(AIC, ties.method = "first") == 1)
      j <- c(j, s)
      i <- i[i != s]
      v <- v + 1
    }
  }
  else if (model == "glm") {
    while (v < vmax) {
      AIC <- rep(Inf, dim(df)[2])
      for (k in i) {
        d <- df[, c(j, k)]
        f <- glm(y ~ (.), family = binomial("logit"), data = d)
        AIC[k] <- AIC(f)
      }
      s <- which(rank(AIC, ties.method = "first") == 1)
      j <- c(j, s)
      i <- i[i != s]
      v <- v + 1
    }
  }
  else {
    stop("\"model\" can only be 'lm' or 'glm'")
  }

  return(j)
}
