#' Random Lasso Regression (Continuous)
#'
#' rd.lss.linr is a function to run random lasso regression for a data set with
#' continuous dependent variable.
#'
#' y  independent variable, a binary vector
#'
#' X  dependent variables, a n by p matrix
#' @export




rd.lss.linr <- function(y, X, q1, q2, nfolds = 5) {
  X <- as.matrix(X)
  df <- data.frame(y, X)

  n <- dim(X)[1]
  p <- dim(X)[2]
  #  if (n < p) {
  #    warning("The number of predictors is greater than the number of observations. Insignificant variables are elimated.")
  #    df <- df[, fwd.sel(y, X, vmax = n-1, model = "lm", shrinkage = T)]
  #    p <- dim(df)[2] - 1
  #  }

  if (q1 > p | q2 > p) {
    stop("q1, q2 > p, please choose appropriate q1 and q2 values.")
  }

  f <- glmnet::cv.glmnet(X, y, alpha = 1, nfolds = nfolds)
  l <- f$lambda.1se
  names <- rownames(coef(f))

  x <- rbind()
  B <- 1000
  for (i in 1:B) {
    j <- sample(1:n, n, replace = T)
    df.b <- df[j, ]
    X.b <- as.matrix(df.b[, -1])
    y.b <- df.b[, 1]

    b <- rep(NA, p+1)
    k <- sample(2:(p+1), q1, replace = F)
    b[-k] <- 0

    c <- coef(glmnet::glmnet(X.b, y.b, alpha = 1, lambda = l))[, 1]
    b[k] <- c[k]
    b[1] <- 1
    x <- rbind(x, b)
  }
  x <- abs(colSums(x) / B)

  coefficients <- rbind()
  for (i in 1:B) {
    j <- sample(1:n, n, replace = T)
    df.b <- df[j, ]
    X.b <- as.matrix(df.b[, -1])
    y.b <- df.b[, 1]

    b <- rep(NA, p+1)
    k <- sample(1:(p+1), q2, prob = x, replace = F)
    b[-k] <- 0

    c <- coef(glmnet::glmnet(X.b, y.b, alpha = 1, lambda = l))[, 1]
    b[k] <- c[k]
    coefficients <- rbind(coefficients, b)
  }
  coefficients <- colSums(coefficients) / B
  names(coefficients) <- names

  fitted.values <- cbind(rep(1, n), X) %*% as.matrix(coefficients)

  r <- list(coefficients = coefficients, fitted.values = fitted.values)

  return(r)
}
