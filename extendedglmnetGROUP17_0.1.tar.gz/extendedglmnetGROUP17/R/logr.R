#' Logistic regression
#'
#' logr is a function to run logistic regression for a data set with continuous
#' dependent variable.
#'
#' y  independent variable, a binary vector
#'
#' X  dependent variables, a n by p matrix
#'
#' @export



logr <- function(y, X) {
  if (length(unique(y)) > 2) {
    stop("The response variable is not binary, use the function \"linr()\".")
  }
  else {
    if(!is.numeric(y)) {
      y <- factor(y)
    }
  }

  df <- data.frame(y, X)

  n <- dim(X)[1]
  p <- dim(X)[2]
  if (n < p) {
    warning("The number of predictors is greater than the number of observations. Insignificant variables are elimated.")
    df <- df[, fwd.sel(y, X, vmax = n-1, model = "glm", shrinkage = T)]
  }

  f <- glm(y ~ (.), family = binomial("logit"), data = df)
  coefficients <- summary(f)$coefficients
  fitted.values <- f$fitted.values

  r <- list(glm = f, coefficients = coefficients, fitted.values = fitted.values)

  return(r)
}
