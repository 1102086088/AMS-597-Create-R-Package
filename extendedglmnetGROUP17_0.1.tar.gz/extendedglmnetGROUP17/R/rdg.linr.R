#' Ridge Regression (Continuous)
#'
#' rdg.linr is a function to run lasso regression for a data set with continuous
#' dependent variable.
#'
#' y  independent variable, a continuous vector
#'
#' X  dependent variables, a n by p matrix

#' @export


rdg.linr <- function(y, X, nfolds = 5) {
  if (length(unique(y)) == 2) {
    warning("The response variable is binary, should apply logstic regression. Use the function \"logr()\".")
  }

  X <- as.matrix(X)
  df <- data.frame(y, X)

  n <- dim(X)[1]
  p <- dim(X)[2]
  #  if (n < p) {
  #    warning("The number of predictors is greater than the number of observations. Insignificant variables are elimated.")
  #    df <- df[, fwd.sel(y, X, vmax = n-1, model = "lm", shrinkage = T)]
  #    p <- dim(df)[2] - 1
  #  }

  l <- glmnet::cv.glmnet(X, y, alpha = 0, nfolds = nfolds)$lambda.1se
  f <- glmnet::glmnet(X, y, alpha = 0, lambda = l)
  est <- coef(f)[, 1]

  B <- 100
  est.b <- c()
  for (i in 1:B) {
    i <- sample(1:n, n, replace = TRUE)
    df.b <- df[i, ]
    X.b <- as.matrix(df.b[, -1])
    y.b <- df.b[, 1]
    f.b <- glmnet::glmnet(X.b, y.b, alpha = 0, lambda = l)
    est.b <- c(est.b, coef(f.b)[, 1])
  }
  est.b <- matrix(est.b, ncol = B)
  sd.err <- rep(NA, p+1)
  for (i in 1:(p+1)) {
    sd.err[i] <- sd(est.b[i, ])
  }

  z <- est / sd.err
  pvals <- 2 * pt(abs(z), df = Inf, lower.tail = FALSE)

  coefficients <- cbind(est, sd.err, z, pvals)
  colnames(coefficients) <- c("Estimate", "Std. Error", "z value", "p-value")

  fitted.values <- predict(f, X)

  r <- list(rdg.lm = f, coefficients = coefficients, fitted.values = fitted.values)

  return(r)
}
